"""trame + PyVista front end.

    python -m mos.app [--spec model.mos] [--port 8080]

The drawer holds the model description (see mos/core/spec.py) and the view controls;
the 3D view is a server-side-rendered VTK scene.
"""
from __future__ import annotations

import traceback
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pyvista as pv
from pyvista.trame.ui import plotter_ui
from trame.app import get_server
from trame.ui.vuetify3 import SinglePageWithDrawerLayout
from trame.widgets import html
from trame.widgets import vuetify3 as v3

from mos import viz
from mos.core.solver import solve_case
from mos.core.spec import build, parse_spec
from mos.templates import TEMPLATES

pv.OFF_SCREEN = True


def main(argv=None):
    """Build the UI and start the trame server (blocks until stopped)."""
    server = get_server(client_type="vue3")
    state, ctrl = server.state, server.controller
    parser = server.cli
    parser.add_argument("--spec", help="model description file to open at startup")
    args, _ = parser.parse_known_args(argv)

    pl = pv.Plotter()
    S = SimpleNamespace(grid=None, scalars={}, u_pts=None, res=None)   # current solution

    # ------------------------------------------------------------ scene
    def update_scene(reset_camera=False):
        """Redraw the 3D view from the current solution and view controls."""
        if S.grid is None or state.field not in S.scalars:
            return
        arr, kind = S.scalars[state.field]
        div = viz.STRESS_UNITS[state.stress_unit] if kind == "stress" else 1.0
        label = f"{state.field} [{state.stress_unit}]" if kind == "stress" else state.field
        base = S.grid
        g = base.copy()
        g.points = base.points + float(state.scale) * S.u_pts
        g.point_data["s"] = arr / div
        if state.clip_axis != "none":
            ax = "xyz".index(state.clip_axis)
            g = g.clip(normal=state.clip_axis,
                       origin=viz.clip_origin(base.bounds, ax, float(state.clip_pos)))
        lo, hi = float(arr.min() / div), float(arr.max() / div)
        if hi - lo < 1e-30:
            hi = lo + 1e-30
        pl.clear()
        pl.add_mesh(g, scalars="s", cmap="turbo", clim=[lo, hi],
                    show_edges=bool(state.show_edges), scalar_bar_args={"title": label})
        if float(state.scale) > 0:        # faint outline of the undeformed shape
            pl.add_mesh(base.extract_surface().extract_feature_edges(30),
                        color="gray", line_width=1, opacity=0.5)
        if reset_camera:
            pl.reset_camera()
        ctrl.view_update()

    # ------------------------------------------------------------ solve
    def run_solve():
        """Parse the model text, solve it, refresh the plot and status panel; report errors in the UI."""
        try:
            state.status, state.status_type = "Solving ...", "info"
            state.flush()
            spec = parse_spec(state.spec_text)
            model, case = build(spec)
            res = solve_case(model, case)
            S.res, S.grid = res, viz.to_pyvista(model.mesh)
            S.scalars = viz.compute_scalars(res)
            S.u_pts = np.ascontiguousarray(res.u_nodal.T)
            state.field_items = list(S.scalars)
            if state.field not in S.scalars:
                state.field = "von Mises"
            factor = viz.suggest_scale(S.grid.points, res.u_nodal)
            state.scale_max = 3 * factor
            state.scale_step = 3 * factor / 300
            state.scale = factor
            div = viz.STRESS_UNITS[state.stress_unit]
            n_dof = res.u.size
            state.status = (
                f"{S.grid.n_cells} cells, {S.grid.n_points} vertices, {n_dof} DOFs\n"
                f"max |u| = {S.scalars['|u|'][0].max():.4g}\n"
                f"max von Mises = {S.scalars['von Mises'][0].max() / div:.4g} {state.stress_unit}\n"
                f"reactions = {np.array2string(res.reactions, precision=4)}\n"
                f"equilibrium error = {res.equilibrium_error:.2e}")
            state.status_type = "success" if res.equilibrium_error < 1e-6 else "warning"
            update_scene(reset_camera=True)
        except Exception as e:               # show every failure in the UI, keep serving
            traceback.print_exc()
            state.status = f"{type(e).__name__}: {e}"
            state.status_type = "error"

    ctrl.run_solve = run_solve

    # ------------------------------------------------------------ state
    state.update({
        "spec_text": TEMPLATES[next(iter(TEMPLATES))],
        "template": None, "templates": list(TEMPLATES),
        "status": "Edit the model on the left, then press Solve.", "status_type": "info",
        "field": "von Mises", "field_items": [],
        "stress_unit": "MPa", "stress_units": list(viz.STRESS_UNITS),
        "scale": 1.0, "scale_max": 1.0, "scale_step": 0.01,
        "show_edges": True, "clip_axis": "none", "clip_axes": ["none", "x", "y", "z"],
        "clip_pos": 0.5,
    })
    if args.spec:
        state.spec_text = Path(args.spec).read_text()

    @state.change("template")
    def _load_template(template, **kw):
        if template in TEMPLATES:
            state.spec_text = TEMPLATES[template]

    @state.change("field", "stress_unit", "scale", "show_edges", "clip_axis", "clip_pos")
    def _redraw(**kw):
        update_scene()

    # ------------------------------------------------------------ layout
    with SinglePageWithDrawerLayout(server) as layout:
        layout.title.set_text("MoS Analyzer")
        layout.drawer.width = 460
        with layout.drawer:
            with v3.VContainer(fluid=True, classes="pa-3"):
                v3.VSelect(v_model=("template",), items=("templates",), label="Load example",
                           density="compact", hide_details=True, classes="mb-2")
                v3.VTextarea(v_model=("spec_text",), rows=20, variant="outlined",
                             hide_details=True, no_resize=True,
                             style="font-family: monospace; font-size: 12px;")
                v3.VBtn("Solve", block=True, color="primary", classes="my-2", click=ctrl.run_solve)
                html.Pre("{{ status }}", style="white-space: pre-wrap; font-size: 12px;")
                v3.VDivider(classes="my-3")
                v3.VSelect(v_model=("field",), items=("field_items",), label="Show",
                           density="compact", hide_details=True, classes="mb-2")
                v3.VSelect(v_model=("stress_unit",), items=("stress_units",), label="Stress unit",
                           density="compact", hide_details=True, classes="mb-2")
                v3.VSlider(v_model=("scale",), min=0, max=("scale_max",), step=("scale_step",),
                           label="Deformation scale", hide_details=True, density="compact")
                v3.VSwitch(v_model=("show_edges",), label="Mesh edges", hide_details=True,
                           density="compact")
                v3.VSelect(v_model=("clip_axis",), items=("clip_axes",), label="Section plane normal",
                           density="compact", hide_details=True, classes="mb-2")
                v3.VSlider(v_model=("clip_pos",), min=0, max=1, step=0.01,
                           disabled=("clip_axis === 'none'",), label="Section position",
                           hide_details=True, density="compact")
        with layout.content:
            with v3.VContainer(fluid=True, classes="pa-0 fill-height"):
                view = plotter_ui(pl, mode="server")
                ctrl.view_update = view.update

    server.start()
