"""Results -> things to draw. The array helpers are pure numpy; to_pyvista needs pyvista + meshio."""
from __future__ import annotations

import numpy as np

from .core import post

STRESS_UNITS = {"Pa": 1.0, "kPa": 1e3, "MPa": 1e6, "GPa": 1e9}


def compute_scalars(res) -> dict:
    """name -> (nodal array (nnodes,), kind) with kind in {'disp', 'stress', 'strain'}.
    `res` needs u_nodal (3, n), sig_nodal (3, 3, n), eps_nodal (3, 3, n)."""
    u, S, E = res.u_nodal, res.sig_nodal, res.eps_nodal
    s, _ = post.principal(S)
    e, _ = post.principal(E)
    out = {"|u|": (np.linalg.norm(u, axis=0), "disp"),
           "ux": (u[0], "disp"), "uy": (u[1], "disp"), "uz": (u[2], "disp"),
           "von Mises": (post.von_mises(S), "stress"),
           "σ1 (max principal)": (s[0], "stress"),
           "σ3 (min principal)": (s[2], "stress"),
           "Tresca": (s[0] - s[2], "stress")}
    for name, (i, j) in {"σxx": (0, 0), "σyy": (1, 1), "σzz": (2, 2),
                         "τxy": (0, 1), "τyz": (1, 2), "τxz": (0, 2)}.items():
        out[name] = (S[i, j], "stress")
    for name, (i, j) in {"εxx": (0, 0), "εyy": (1, 1), "εzz": (2, 2)}.items():
        out[name] = (E[i, j], "strain")
    for name, (i, j) in {"γxy": (0, 1), "γyz": (1, 2), "γxz": (0, 2)}.items():
        out[name] = (2 * E[i, j], "strain")          # engineering shear strain
    out["ε1 (max principal)"] = (e[0], "strain")
    return out


def suggest_scale(points, u_nodal) -> float:
    """Deformation factor that makes the largest displacement ~10 % of the model size."""
    umax = float(np.linalg.norm(u_nodal, axis=0).max())
    diag = float(np.linalg.norm(np.ptp(np.asarray(points), axis=0)))
    return 0.1 * diag / umax if umax > 0 else 1.0


def clip_origin(bounds, axis: int, frac: float):
    """Point on the clip plane at fraction `frac` of the bounding box along `axis`."""
    lo, hi = bounds[2 * axis], bounds[2 * axis + 1]
    o = [0.5 * (bounds[0] + bounds[1]), 0.5 * (bounds[2] + bounds[3]), 0.5 * (bounds[4] + bounds[5])]
    o[axis] = lo + frac * (hi - lo)
    return o


def to_pyvista(mesh):
    """scikit-fem mesh -> pyvista UnstructuredGrid (same node order as mesh.p)."""
    import pyvista as pv
    from skfem.io.meshio import to_meshio
    return pv.from_meshio(to_meshio(mesh))
