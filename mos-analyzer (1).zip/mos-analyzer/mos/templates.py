"""Example model descriptions shown in the app's 'Load example' menu."""

TEMPLATES = {
    "Cantilever - tip load": """\
# Cantilever, tip shear load.  Units: SI (m, N, Pa).
# Beam theory: tip deflection = P L^3 / (3 E I),  I = W H^3 / 12
param L = 10
param H = 1
param W = 1
param P = 1e6

mesh     box L H W 20 2 2
material E = 210e9, nu = 0.3, rho = 7850

region   fixed facets x < 1e-9
region   tip   facets x > L - 1e-9

support  fixed xyz
traction tip 0, -P/(H*W), 0
""",
    "Cantilever - self weight": """\
# Cantilever under its own weight (body force from rho, defined by 'material').
# Beam theory: tip deflection = q L^4 / (8 E I),  q = rho g W H
param L = 10
param H = 1
param W = 1
param g = 9.81

mesh     box L H W 20 2 2
material E = 210e9, nu = 0.3, rho = 7850

region   fixed facets x < 1e-9
support  fixed xyz

body     0, -rho*g, 0
# any field works, e.g. a body force that doubles toward the tip:
# body   0, -rho*g*(1 + x/L), 0
""",
    "Bar - torsion": """\
# Square bar twisted by a torque T about its axis (a moment along the end-face normal).
param L = 10
param a = 1
param T = 1e5

mesh     box L a a 24 4 4
material E = 210e9, nu = 0.3

region   fixed facets x < 1e-9
region   tip   facets x > L - 1e-9

support  fixed xyz
moment   tip T, 0, 0
""",
    "Cantilever - partial pressure": """\
# Pressure on the top face over the outer half only, built with step().
# Equivalent:  pressure top where(x > L/2, p0, 0)
param L = 10
param H = 1
param W = 1
param p0 = 5e6

mesh     box L H W 30 3 3
material E = 210e9, nu = 0.3

region   fixed facets x < 1e-9
region   top   facets y > H/2 - 1e-9

support  fixed xyz
pressure top step(x - L/2) * p0
""",
}
