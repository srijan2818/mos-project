# The app

```text
python -m mos.app                       # starts a local server and prints its address
python -m mos.app --spec model.mos      # start with a model file loaded
python -m mos.app --port 8080
```

The app is a [trame](https://kitware.github.io/trame/) server: a Python process renders the 3D
scene with PyVista (VTK) and streams it to a browser tab.

## Workflow

1. Pick a model from **Load example**, or edit the text in the editor (see
   [model-language.md](model-language.md)). The examples are *Cantilever - tip load*,
   *Cantilever - self weight*, *Bar - torsion* and *Cantilever - partial pressure*.
2. Press **Solve**. The status panel shows the cell and DOF counts, the maximum displacement and
   von Mises stress, the total reaction, and the equilibrium error. The status turns green when the
   equilibrium error is below 1e-6 and amber otherwise; errors in the model text are shown in red
   with their line number.
3. Explore with the view controls.

## Controls

| Control | Effect |
|---|---|
| **Show** | scalar plotted on the body: `\|u\|`, `ux uy uz`, von Mises, principal stresses, Tresca, every stress component, strain components (`gamma` are engineering shear strains), principal strain |
| **Stress unit** | Pa, kPa, MPa or GPa; display only, the model is not rescaled |
| **Deformation scale** | multiplies the displacement drawn. It starts at the factor that makes the largest displacement about 10 % of the model size; the slider goes to 3x that. At 0 the body is undeformed. A faint outline of the undeformed shape is drawn whenever the scale is above 0. |
| **Mesh edges** | draws the element edges |
| **Section plane normal / position** | cuts the body with a plane normal to x, y or z at a fraction of the bounding box. The colour range stays that of the whole body. |

Colours show the smoothed nodal values (see [theory.md](theory.md), section 6): good for the
overall picture, not for the exact peak.

## How it is built

`mos/app/main.py` keeps all UI state in trame's `state` (`spec_text`, `field`, `stress_unit`,
`scale`, `show_edges`, `clip_axis`, `clip_pos`, ...). The Solve button runs `parse_spec`, `build`
and `solve_case`, converts the mesh with `viz.to_pyvista`, computes the plottable scalars with
`viz.compute_scalars` and stores them; changing any view control redraws from the stored solution
without re-solving. All numerical work is in `mos.core`; the app only wires it to widgets.

## Troubleshooting

* **Nothing happens or a Python error on start**: the app needs `pyvista`, `trame`, `trame-vtk`,
  `trame-vuetify` and `meshio` (`pip install -r requirements.txt`). On a headless Linux machine
  VTK needs an off-screen OpenGL backend (OSMesa or EGL).
* **Red status with a line number**: a model-text error; see the table in
  [model-language.md](model-language.md).
* **Huge displacements or a warning status**: usually an under-constrained model (add supports).
* **A hex mesh looks scrambled**: the viewer relies on scikit-fem's meshio export for node order
  on hexahedra; tetrahedra (the default) are the tested path. Report it.
* **A solve error mentioning a scikit-fem call**: see [testing.md](testing.md), "First run".
