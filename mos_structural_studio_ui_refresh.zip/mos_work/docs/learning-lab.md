# Learning Lab

The app has a dedicated **Learning Lab** screen, separate from the 3D finite-element
Analysis Workspace. It is an interactive course companion for developing intuition about
stress transformation and common mechanics-of-materials calculations.

## 3D stress-tensor explorer

Enter the six independent components of a symmetric Cauchy stress tensor, in MPa:

```text
        [ σxx   τxy   τzx ]
σ  =    [ τxy   σyy   τyz ]
        [ τzx   τyz   σzz ]
```

Tension is positive. The plane normal is parameterised by azimuth `θ` and elevation `φ`:

```text
n = [cos(φ) cos(θ), cos(φ) sin(θ), sin(φ)]ᵀ
 t = σ n
σn = n · t
τvector = t - σn n
τ = ||τvector||
```

The screen updates the oriented-plane diagram, traction vector, normal stress and shear
magnitude as the tensor or plane orientation changes. The principal stresses are the sorted
eigenvalues `σ1 ≥ σ2 ≥ σ3` of the symmetric tensor; the corresponding eigenvectors are the
principal-plane normals. The Mohr view draws all three 3D circles `(σ1, σ2)`, `(σ2, σ3)` and
`(σ1, σ3)` with equal plot scales so they remain geometrically circular. The largest circle radius
is the maximum shear stress `(σ1 - σ3) / 2`.

The panel also reports von Mises stress and the Tresca principal-stress difference. **Save case A**
records the current maximum principal stress; the live difference from that saved value updates
as the inputs change.

## Mechanics quick checks

The quick-check panel contains three compact textbook models:

* **Beam bending:** rectangular section, `I = b h³ / 12` and `σmax = 6 M / (b h²)`.
* **Shaft torsion:** solid circular shaft, `J = π d⁴ / 32`, `τmax = 16 T / (π d³)` and `θ = T L / (G J)`.
* **Thin-wall pressure vessel:** closed-end cylinder, `σhoop = p d / (2 t)` and `σlongitudinal = p d / (4 t)`.

All inputs and outputs show their units. These are idealised analytical teaching checks, not
code-compliant design verification. In particular, the vessel panel uses membrane theory and
warns when the diameter-to-thickness ratio makes the thin-wall assumption weak. The beam and
shaft panels assume linear elasticity and the named idealised section/member.

## Course companion

The chapter cards follow the public contents of Ajeet Kumar's *Solid Mechanics for Undergraduates
using vectors and tensors*: mathematical preliminaries; stress and traction; principal planes and
Mohr's circle; strain and constitutive laws; axisymmetric problems and beams; energy methods and
theories of failure. The **Open IIT Delhi course reference** link opens the book's public web page.

## Important distinction from FEA results

The Learning Lab uses user-entered point stresses and closed-form formulae. It does not read or
modify the current mesh solution. For geometry, boundary conditions, loads, displacement fields
and spatial stress contours, switch back to **Analysis workspace**. The FEA solver's assumptions
and limitations remain documented in [theory.md](theory.md).
